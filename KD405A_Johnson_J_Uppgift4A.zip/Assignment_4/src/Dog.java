
public class Dog {
	
	//Instance fields
	private String name;
		
	
	//Constructor
	public Dog (String name){
		this.name = name;
		
	}
	
	public String getName(){
		return this.name;
	}
	
	
}
